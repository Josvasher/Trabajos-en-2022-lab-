print("Programa de patron")

for i in range (0, 10):
  for n in range (0,i+1):
    print("* ", end="")
  print()